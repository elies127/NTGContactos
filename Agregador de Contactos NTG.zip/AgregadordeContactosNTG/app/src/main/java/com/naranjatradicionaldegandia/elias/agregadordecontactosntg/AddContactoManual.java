package com.naranjatradicionaldegandia.elias.agregadordecontactosntg;

import android.app.Activity;

public class AddContactoManual extends Activity {
}
